#include <PinsManager.h>

void setupRelay() {
  pins.addOutput(8);
}
