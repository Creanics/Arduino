#include <PinsManager.h>

void setupSensor() {
  pins.addInput(A0);
}
