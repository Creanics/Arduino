#include <Arduino.h>
#include <PinsManager.h>
#include "Button.h"

void setupButton() {
  pins.addInput(2);
}
